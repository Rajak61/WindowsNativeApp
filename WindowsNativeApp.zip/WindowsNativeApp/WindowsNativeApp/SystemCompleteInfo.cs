﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsNativeApp
{
    internal class SystemCompleteInfo
    {
        public SystemInformationEntity systemInformation;
        public MemoryCpuUsageEntity memory_CPUUsage;
        public List<DiskUsageEntity> diskUsage;
        public string wwnDetails;
        public string oracleDBInstances;
        public PackageUpdates packageUpdates;
       
    }
}
