﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Management;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace WindowsNativeApp
{
    public class SystemInformation
    {
        public SystemInformationEntity GetSystemInformation()
        {
            SystemInformationEntity entity = new SystemInformationEntity();
            entity.hostname = Environment.MachineName;
            long tickCountMs = Environment.TickCount;
            var uptime = TimeSpan.FromMilliseconds(tickCountMs);
            entity.uptime = uptime.ToString();
            //Get computer system details
            SelectQuery query = new SelectQuery(@"Select * from Win32_ComputerSystem");
            ManagementObjectSearcher searcher = new ManagementObjectSearcher(query);

            foreach (ManagementObject mo in searcher.Get())
            {
                PropertyDataCollection searcherProperties = mo.Properties;
                foreach (PropertyData sp in searcherProperties)
                {
                    if(sp.Name == "Manufacturer")
                    {
                        entity.manufacturer = sp.Value.ToString();
                    }

                    if (sp.Name == "UserName")
                    {
                        entity.activeUser = sp.Value.ToString();
                    }
                    if (sp.Name == "Model")
                    {
                        entity.machineType = sp.Value.ToString();
                    }
                    if (sp.Name == "SystemType")
                    {
                        entity.systemDetails = sp.Value.ToString();
                    }
                }
            }

            //Get OS Details
            query = new SelectQuery(@"Select * from Win32_OperatingSystem");
            searcher = new ManagementObjectSearcher(query);
            foreach (ManagementObject mo in searcher.Get())
            {
                PropertyDataCollection searcherProperties = mo.Properties;
                foreach (PropertyData sp in searcherProperties)
                {
                    if (sp.Name == "Name")
                    {
                        entity.operatingSystem = sp.Value.ToString();
                    }

                    if (sp.Name == "Version")
                    {
                        entity.version = sp.Value.ToString();
                    }
                    if (sp.Name == "SerialNumber")
                    {
                        entity.serialNumber = sp.Value.ToString();
                    }
                   
                }
            }
            //Get Processor Details
            query = new SelectQuery(@"Select * from Win32_Processor");
            searcher = new ManagementObjectSearcher(query);
            foreach (ManagementObject mo in searcher.Get())
            {
                PropertyDataCollection searcherProperties = mo.Properties;
                foreach (PropertyData sp in searcherProperties)
                {
                    if (sp.Name == "Name")
                    {
                        entity.processorName = sp.Value.ToString();
                    }

                }
            }
            entity.architecture = Environment.GetEnvironmentVariable("PROCESSOR_ARCHITECTURE");

            //Get Physical Memory Details
            query = new SelectQuery(@"Select * from Win32_PhysicalMemory");
            searcher = new ManagementObjectSearcher(query);
            Int64 ramAvailable = 0;
            foreach (ManagementObject mo in searcher.Get())
            {
                PropertyDataCollection searcherProperties = mo.Properties;
                foreach (PropertyData sp in searcherProperties)
                {
                    if (sp.Name == "Capacity")
                    {
                        string mem = sp.Value.ToString();
                        Int64 ramGB = 0;
                        Int64.TryParse(mem , out ramAvailable);
                        ramGB = (((ramAvailable/1024)/1024)/1024);
                        break;
                    }

                }
            }
            entity.systemMainIP = GetLocalIPAddress();

            Process proc = Process.GetCurrentProcess();
            float memoryUsage = 100 * (ramAvailable - proc.PrivateMemorySize64) / ramAvailable;
            entity.usageRAM = memoryUsage.ToString() + "%";
            entity.productName = "";
            entity.kernel = "";
            //Get Oracle DB Instance
            //query = new SelectQuery(@"Select * from V$ACTIVE_INSTANCES");
            //searcher = new ManagementObjectSearcher(query);
            //foreach (ManagementObject mo in searcher.Get())
            //{
            //    PropertyDataCollection searcherProperties = mo.Properties;
            //    foreach (PropertyData sp in searcherProperties)
            //    {
            //        if (sp.Name == "Instance")
            //        {
            //            entity.OracleDbInstance = sp.Value.ToString();
            //            break;
            //        }

            //    }
            //}

            return entity;
        }

        public static string GetLocalIPAddress()
        {
            var host = Dns.GetHostEntry(Dns.GetHostName());
            foreach (var ip in host.AddressList)
            {
                if(ip.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                {
                    return ip.ToString();
                }
            }
            throw new Exception("No network adapters with an IPv4 address in the system");
        }
    }

    public class SystemInformationEntity
    {
        public string hostname { get; set; }
        public string uptime { get; set; }

        public string manufacturer { get; set; }
        public string productName { get; set; }
        public string version { get; set; }
        public string serialNumber { get; set; }
        public string machineType { get; set; }
        public string systemDetails { get; set; }
        public string availableRAM { get; set; }
        public string usageRAM { get; set; }
        public string operatingSystem { get; set; }

        public string osVersion{get;set;}
        public string osFamily { get; set; }
        public string kernel { get; set; }
        public string architecture { get; set; }
        public string processorName { get; set; }
        public string activeUser { get; set; }
        public string systemMainIP { get; set; }
        //public string OracleDbInstance { get; set; }
        //public string PackageUpdate { get; set; }

        //public string wwnDetails { get; set; }
    }

    public class PackageUpdates
    {
        public string desc { get; set; }


    }

}
